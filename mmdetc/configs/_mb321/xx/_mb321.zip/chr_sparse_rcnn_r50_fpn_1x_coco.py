# chr_sparse_rcnn_r50_fpn_1x_coco.py
print("where is chr_sparse_rcnn_r50_fpn_1x_coco.py? __file__={}".format(__file__))
from pt_flag import NUM_CLASS_SEG, MM_PTH_TRAINED, BB_SEG #, MM_PTH_TRAINED,
from mmdetection.configs.mb321.mm_chr_base import dataset_type as dataset_type
from mmdetection.configs.mb321.mm_chr_base import data as data
from mmdetection.configs.mb321.mm_chr_base import evaluation as evaluation
from mmdetection.configs.mb321.mm_chr_base import log_config as log_config
from mmdetection.configs.mb321.mm_chr_base import init_cfg as init_cfg
from mmdetection.configs.mb321.mm_chr_base import load_from as load_from
from mmdetection.configs.mb321.mm_chr_base import depth as depth
# if depth != 50: input(f"?? 'defrom_' expect depth=50, not{depth}")
_base_ = [
    # '../_base_/datasets/coco_detection.py',
    '../_base_/datasets/coco_detection_mb321.py', # coco_instance_mb321
    '../_base_/schedules/mb321_schedule.py',
    '../_base_/mb321_runtime.py'
]
# num_proposals, _del, lr_step, runner_max = 300, True, [27, 33], 36

# depth_int = 50 if '50' in BB_SEG else 101 if '101' in BB_SEG else -1
if '300' in BB_SEG:
    # lr_step = [27, 33]; runner_max = 36
    num_proposals, _del = 300, True
    img_scale = [(480, 1333), (512, 1333), (544, 1333), (576, 1333), (608, 1333), (640, 1333),
                 (672, 1333), (704, 1333), (736, 1333), (768, 1333), (800, 1333)]
else: # 100
    # lr_step = [8, 11]; runner_max = 36
    num_proposals, _del = 100, False
    min_values = (480, 512, 544, 576, 608, 640, 672, 704, 736, 768, 800)
    # train_pipeline.append(dict(type='Resize', img_scale=[(1333, value) for value in min_values], multiscale_mode='value', keep_ratio=True))

num_stages = 6
model = dict(
    type='SparseRCNN',
    backbone=dict(
        type='ResNet',
        depth=depth,
        num_stages=4,
        out_indices=(0, 1, 2, 3),
        frozen_stages=1,
        norm_cfg=dict(type='BN', requires_grad=True),
        norm_eval=True,
        style='pytorch',
        init_cfg=init_cfg),
    neck=dict(
        type='FPN',
        in_channels=[256, 512, 1024, 2048],
        out_channels=256,
        start_level=0,
        add_extra_convs='on_input',
        num_outs=4),
    rpn_head=dict(
        type='EmbeddingRPNHead',
        num_proposals=num_proposals,
        proposal_feature_channel=256),
    roi_head=dict(
        type='SparseRoIHead',
        num_stages=num_stages,
        stage_loss_weights=[1] * num_stages,
        proposal_feature_channel=256,
        bbox_roi_extractor=dict(
            type='SingleRoIExtractor',
            roi_layer=dict(type='RoIAlign', output_size=7, sampling_ratio=2),
            out_channels=256,
            featmap_strides=[4, 8, 16, 32]),
        bbox_head=[dict(type='DIIHead',
                num_classes=NUM_CLASS_SEG,
                num_ffn_fcs=2,
                num_heads=8,
                num_cls_fcs=1,
                num_reg_fcs=3,
                feedforward_channels=2048,
                in_channels=256,
                dropout=0.0,
                ffn_act_cfg=dict(type='ReLU', inplace=True),
                dynamic_conv_cfg=dict(
                    type='DynamicConv',
                    in_channels=256,
                    feat_channels=64,
                    out_channels=256,
                    input_feat_shape=7,
                    act_cfg=dict(type='ReLU', inplace=True),
                    norm_cfg=dict(type='LN')),
                loss_bbox=dict(type='L1Loss', loss_weight=5.0),
                loss_iou=dict(type='GIoULoss', loss_weight=2.0),
                loss_cls=dict(
                    type='FocalLoss',
                    use_sigmoid=True,
                    gamma=2.0,
                    alpha=0.25,
                    loss_weight=2.0),
                bbox_coder=dict(type='DeltaXYWHBBoxCoder',
                    clip_border=False,
                    target_means=[0., 0., 0., 0.],
                    target_stds=[0.5, 0.5, 1., 1.])) for _ in range(num_stages)]
        ), # roi_head
    # training and testing settings
    train_cfg=dict(rpn=None,
                   rcnn=[dict(assigner=dict(type='HungarianAssigner',
                    cls_cost=dict(type='FocalLossCost', weight=2.0),
                    reg_cost=dict(type='BBoxL1Cost', weight=5.0),
                    iou_cost=dict(type='IoUCost', iou_mode='giou', weight=2.0)),
                sampler=dict(type='PseudoSampler'), pos_weight=1) for _ in range(num_stages)
        ]),
    test_cfg=dict(rpn=None, _delete_=_del, rcnn=dict(max_per_img=num_proposals))
) # model

# # delete me !!
# # optimizer
# optimizer = dict(_delete_=True, type='AdamW', lr=0.000025, weight_decay=0.0001)
# optimizer_config = dict(_delete_=True, grad_clip=dict(max_norm=1, norm_type=2))
# # learning policy
# lr_config = dict(policy='step', step=[8, 11])
# runner = dict(type='EpochBasedRunner', max_epochs=700)


print("chr_sparse_rcnn_r50_fpn_1x_coco.py, _base_={}\n load_from={}".format(_base_, load_from))
# print("train_pipeline={}".format(train_pipeline))