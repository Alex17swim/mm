# abn_seg.py
print("where is abn_seg.py? __file__={}".format(__file__))
from pt_flag import BB_ABN, NUM_CLASS_ABN, ABN_PRE_TRAIN, ABN_PTH_TRAINED, CLS_MAX_EPOCH,\
    LOG_GAP_VAL, NUM_WORKERS_SEG, SAMPLES_PER_GPU_SEG, ABN_PTH_TRAINED, MM_DATA_MB321, ICHR_CLASSES
from pt_flag import IMG_NORM_CFG as img_norm_cfg
_base_ = [
    # '../_base_/schedules/mb321_schedule.py',
    '../_base_/mb321_runtime.py'
]
load_from = ABN_PTH_TRAINED
depth = 50
if 'abn_' in BB_ABN: _ck = ''
else: _ck = f'torchvision://resnet{depth}'
init_cfg = dict(type='Pretrained', checkpoint=_ck) if ABN_PRE_TRAIN else ''

# schedule
base_lr, max_epochs = 0.001, CLS_MAX_EPOCH
weight_decay = 0.0001 # 0.05 if 'swin' in bb_name else 0.0001
optimizer = dict(betas=(0.9, 0.999), # _delete_=True, for swin
    type='AdamW', lr=base_lr, weight_decay=weight_decay,
    # paramwise_cfg=dict(custom_keys={'absolute_pos_embed': dict(decay_mult=0.), 'relative_position_bias_table': dict(decay_mult=0.), 'norm': dict(decay_mult=0.), 'backbone': dict(lr_mult=0.1),'sampling_offsets': dict(lr_mult=0.1), 'reference_points': dict(lr_mult=0.1)})
    ) # optimizer
optimizer_config = dict(grad_clip=dict(max_norm=0.1, norm_type=2))
# lr_config = dict(policy='fixed')
lr_config = dict(policy='step', warmup='linear', warmup_iters=500, warmup_ratio=0.001, step=[8, 11] )
runner = dict(type='EpochBasedRunner', max_epochs=max_epochs)

# img_norm_cfg = dict(mean=[123.675, 116.28, 103.53], std=[58.395, 57.12, 57.375], to_rgb=True)
# if BB_SEG == 'mm_pr_3x':img_norm_cfg = dict(mean=[103.530, 116.280, 123.675], std=[1.0, 1.0, 1.0], to_rgb=False)  # use caffe img_norm
size_divisor = 32
_img_scale=[(400, 1333), (500, 1333), (600, 1333)]
keys = ['img'] # , 'gt_bboxes', 'gt_labels']
metric=['bbox'] # 'bbox', 'segm'
# dataset
train_pipeline = [
    dict(type='LoadImageFromFile'),
    dict(type='RandomFlip', flip_ratio=0.5),
    # dict(type='AutoAugment', # for swin, augmentation strategy originates from DETR / Sparse RCNN
    #     policies=[[dict(
    #             type='Resize',
    #             img_scale=[(480, 1333), (512, 1333), (544, 1333), (576, 1333),
    #                        (608, 1333), (640, 1333), (672, 1333), (704, 1333),
    #                        (736, 1333), (768, 1333), (800, 1333)],
    #             multiscale_mode='value', keep_ratio=True)
    #             ],
    #             [dict(type='Resize', img_scale=_img_scale,
    #             multiscale_mode='value', keep_ratio=True),
    #             dict(type='RandomCrop', crop_type='absolute_range', crop_size=(384, 600), allow_negative_crop=True),
    #             dict(type='Resize',
    #             img_scale=[(480, 1333), (512, 1333), (544, 1333), (576, 1333), (608, 1333), (640, 1333),
    #                        (672, 1333), (704, 1333), (736, 1333), (768, 1333), (800, 1333)],
    #             multiscale_mode='value', override=True, keep_ratio=True)]]
    #     ), # AutoAugment
        dict(type='Normalize', **img_norm_cfg),
        dict(type='Pad', size_divisor=size_divisor),
        dict(type='DefaultFormatBundle'),
        dict(type='Collect', keys=keys)    
] # end train_pipeline

# test_pipeline, NOTE the Pad's size_divisor is different from the default
# setting (size_divisor=32). While there is little effect on the performance
# whether we use the default setting or use size_divisor=1.
test_pipeline = [
    dict(type='LoadImageFromFile'),
    dict(type='MultiScaleFlipAug', img_scale=(1333, 800), flip=False,
        transforms=[dict(type='Resize', keep_ratio=True), dict(type='RandomFlip'), dict(type='Normalize', **img_norm_cfg),
            dict(type='Pad', size_divisor=1), dict(type='ImageToTensor', keys=['img']), dict(type='Collect', keys=['img'])
        ])
] # test_pipeline

dataset_type = 'IchrDataset' # !!! IchrDataset
img_train, img_val, img_test = MM_DATA_MB321['ichr_train'], MM_DATA_MB321['ichr_val'], MM_DATA_MB321['ichr_test']
ichr_classes = ICHR_CLASSES # calculate will fly...
data = dict(
    # self.CLASSES = self.get_classes(classes) # from 'mmdetection\mmdet\datasets\custom.py'
    samples_per_gpu=SAMPLES_PER_GPU_SEG, # OK on 2 with batch=69; failed on 1 for with=128
    workers_per_gpu=NUM_WORKERS_SEG, # 2 
    train=dict(type=dataset_type, img_prefix=img_train, pipeline=train_pipeline), # filter_empty_gt=False, classes=ichr_classes, 
    val=dict(type=dataset_type, img_prefix=img_val, pipeline=test_pipeline), # classes=ichr_classes, 
    test=dict(type=dataset_type, img_prefix=img_test, pipeline=test_pipeline) # classes=ichr_classes, 
    ) # data
evaluation = dict(interval=LOG_GAP_VAL, metric=metric)
log_config = dict(interval=5)


# model settings
model = dict(
    type='ResNet',
    backbone=dict(
        type='ResNet', # Abn_Swin, ResNet
        depth=depth,
        num_stages=4,
        out_indices=(0, 1, 2, 3),
        frozen_stages=1,
        norm_cfg=dict(type='BN', requires_grad=True),
        norm_eval=True,
        style='pytorch',
        init_cfg=init_cfg),
    # neck=dict(
    #     type='FPN',
    #     in_channels=[256, 512, 1024, 2048],
    #     out_channels=256,
    #     num_outs=5),
    
    ## model training and testing settings
    # train_cfg=dict(
    #     rpn=dict(
    #         assigner=dict(
    #             type='MaxIoUAssigner',
    #             pos_iou_thr=0.7,
    #             neg_iou_thr=0.3,
    #             min_pos_iou=0.3,
    #             match_low_quality=True,
    #             ignore_iof_thr=-1),
    #         sampler=dict(
    #             type='RandomSampler',
    #             num=256,
    #             pos_fraction=0.5,
    #             neg_pos_ub=-1,
    #             add_gt_as_proposals=False),
    #         allowed_border=-1,
    #         pos_weight=-1,
    #         debug=False),
    #     rpn_proposal=dict(
    #         nms_pre=2000,
    #         max_per_img=1000,
    #         nms=dict(type='nms', iou_threshold=0.7),
    #         min_bbox_size=0),
    #     rcnn=dict(
    #         assigner=dict(
    #             type='MaxIoUAssigner',
    #             pos_iou_thr=0.5,
    #             neg_iou_thr=0.5,
    #             min_pos_iou=0.5,
    #             match_low_quality=True,
    #             ignore_iof_thr=-1),
    #         sampler=dict(
    #             type='RandomSampler',
    #             num=512,
    #             pos_fraction=0.25,
    #             neg_pos_ub=-1,
    #             add_gt_as_proposals=True),
    #         mask_size=28,
    #         pos_weight=-1,
    #         debug=False)), # train_cfg
    
    # test_cfg=dict(
    #     rpn=dict(
    #         nms_pre=1000,
    #         max_per_img=1000,
    #         nms=dict(type='nms', iou_threshold=0.7),
    #         min_bbox_size=0),
    #     rcnn=dict(
    #         score_thr=0.05,
    #         nms=dict(type='nms', iou_threshold=0.5),
    #         max_per_img=100,
    #         mask_thr_binary=0.5) ) # test_cfg
) # model

print("abn_seg.py, _base_={}\n load_from={}".format(_base_, load_from))
