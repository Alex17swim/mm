# chr_point_rend_r50_caffe_fpn_mstrain_1x_coco.py
print("where is chr_point_rend_r50_caffe_fpn_mstrain_1x_coco.py? __file__={}".format(__file__))
from pt_flag import NUM_CLASS_SEG, MM_PTH_TRAINED #, MM_PTH_TRAINED,
from mmdetection.configs.mb321.mm_chr_base import dataset_type as dataset_type
from mmdetection.configs.mb321.mm_chr_base import data as data
from mmdetection.configs.mb321.mm_chr_base import evaluation as evaluation
from mmdetection.configs.mb321.mm_chr_base import log_config as log_config
from mmdetection.configs.mb321.mm_chr_base import init_cfg as init_cfg
from mmdetection.configs.mb321.mm_chr_base import load_from as load_from
from mmdetection.configs.mb321.mm_chr_base import depth as depth
if depth != 50: input(f"?? 'pr_' expect depth=50, not{depth}")
_base_ = [
    '../_base_/models/mask_rcnn_r50_fpn.py',
    # '../_base_/datasets/coco_instance.py',
    '../_base_/datasets/coco_instance_mb321.py',
    '../_base_/schedules/mb321_schedule.py',
    '../_base_/mb321_runtime.py'
]
# _base_ = './mask_rcnn_r50_fpn_1x_coco.py'

# model = dict(roi_head=dict(bbox_head=dict(num_classes=NUM_CLASS_SEG)))
model = dict(
    # backbone=dict(norm_cfg=dict(requires_grad=False), style='caffe',
    #     init_cfg=init_cfg),
    # rpn_head=dict(loss_bbox=dict(type='SmoothL1Loss', beta=1.0 / 9.0, loss_weight=1.0)),
    # roi_head=dict(bbox_roi_extractor=dict(
    #     roi_layer=dict(type='RoIAlign', output_size=7, sampling_ratio=2, aligned=False)),
    #     bbox_head=dict(loss_bbox=dict(type='SmoothL1Loss', beta=1.0, loss_weight=1.0)),
    #     mask_roi_extractor=dict(roi_layer=dict(type='RoIAlign', output_size=14, sampling_ratio=2, aligned=False))
    # ), # end roi_head
    type='PointRend',
    backbone=dict(depth=depth, init_cfg=init_cfg),
    roi_head=dict(
        type='PointRendRoIHead',
        mask_roi_extractor=dict(type='GenericRoIExtractor', aggregation='concat',
            roi_layer=dict(_delete_=True, type='SimpleRoIAlign', output_size=14), out_channels=256, featmap_strides=[4]),
            # roi_layer=dict(type='RoIAlign', output_size=7, sampling_ratio=2, aligned=False)), # from mask_rcnn_r50_fpn.py
        mask_head=dict(_delete_=True, type='CoarseMaskHead', num_fcs=2, in_channels=256, conv_out_channels=256,
            fc_out_channels=1024, num_classes=NUM_CLASS_SEG,
            loss_mask=dict(type='CrossEntropyLoss', use_mask=True, loss_weight=1.0)),
        point_head=dict(type='MaskPointHead', num_fcs=3, in_channels=256, fc_channels=256,
            num_classes=NUM_CLASS_SEG, coarse_pred_each_layer=True,
            loss_point=dict(type='CrossEntropyLoss', use_mask=True, loss_weight=1.0)),
        bbox_head=dict(loss_bbox=dict(type='SmoothL1Loss', beta=1.0, loss_weight=1.0), num_classes=NUM_CLASS_SEG), # from mask_rcnn_r50_fpn.py
        # mask_head=dict(num_classes=NUM_CLASS_SEG),  # from mask_rcnn_r50_fpn.py
        ), # end roi_head
    # model training and testing settings
    train_cfg=dict(rcnn=dict(mask_size=7, num_points=14 * 14, oversample_ratio=3, importance_sample_ratio=0.75)),
    test_cfg=dict(rcnn=dict(subdivision_steps=5, subdivision_num_points=28 * 28, scale_factor=2))
) # end model

print("chr_point_rend_r50_caffe_fpn_mstrain_1x_coco.py, _base_={}\n load_from={}".format(_base_, load_from))